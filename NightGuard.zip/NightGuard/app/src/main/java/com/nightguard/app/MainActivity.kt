package com.nightguard.app

import android.Manifest
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_STRONG
import androidx.biometric.BiometricManager.Authenticators.DEVICE_CREDENTIAL
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : FragmentActivity() {
    val unlocked = mutableStateOf(false)
    private var stopAt = System.currentTimeMillis()
    private val bg = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}
    private val perms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        bg.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
    }

    fun requestPerms() = perms.launch(
        arrayOf(
            Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.SEND_SMS, Manifest.permission.RECEIVE_SMS, Manifest.permission.POST_NOTIFICATIONS
        )
    )

    fun auth() {
        val info = BiometricPrompt.PromptInfo.Builder().setTitle("حارس الليل")
            .setAllowedAuthenticators(BIOMETRIC_STRONG or DEVICE_CREDENTIAL).build()
        BiometricPrompt(this, ContextCompat.getMainExecutor(this), object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(r: BiometricPrompt.AuthenticationResult) { unlocked.value = true }
        }).authenticate(info)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        auth()
        setContent { App(this) }
    }

    override fun onStop() { super.onStop(); stopAt = System.currentTimeMillis() }
    override fun onStart() {
        super.onStart()
        if (unlocked.value && System.currentTimeMillis() - stopAt > 60_000) { unlocked.value = false; auth() }
    }
}

private val Gold = Color(0xFFF5C26B)
private val Red = ButtonDefaults.buttonColors(containerColor = Color(0xFFD63B40), contentColor = Color.White)

@Composable
fun App(a: MainActivity) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = darkColorScheme(
                primary = Gold, onPrimary = Color(0xFF0B1020), background = Color(0xFF0B1020),
                surface = Color(0xFF151B30), onBackground = Color(0xFFE8ECF8), onSurface = Color(0xFFE8ECF8)
            )
        ) {
            Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                if (a.unlocked.value) Main(a) else Column(
                    Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterHorizontally
                ) {
                    Text("حارس الليل", style = MaterialTheme.typography.headlineMedium)
                    Spacer(Modifier.height(16.dp))
                    Button(onClick = { a.auth() }) { Text("فتح التطبيق") }
                }
            }
        }
    }
}

@Composable
fun Main(a: MainActivity) {
    var tab by remember { mutableIntStateOf(0) }
    val names = listOf("الرئيسية", "الخزنة", "الفحص", "الليل")
    val icons = listOf(Icons.Filled.Home, Icons.Filled.Lock, Icons.Filled.Search, Icons.Filled.Notifications)
    Scaffold(bottomBar = {
        NavigationBar {
            names.forEachIndexed { i, n ->
                NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Icon(icons[i], null) }, label = { Text(n) })
            }
        }
    }) { pad ->
        Box(Modifier.padding(pad).padding(16.dp).fillMaxSize()) {
            when (tab) { 0 -> Home(a); 1 -> VaultScreen(); 2 -> ScanScreen(); else -> NightScreen() }
        }
    }
}

@Composable
fun Home(a: MainActivity) {
    val c = LocalContext.current
    var phone by remember { mutableStateOf(Store.get(c, "phone")) }
    var pin by remember { mutableStateOf(Store.get(c, "pin")) }
    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("حارس الليل", style = MaterialTheme.typography.headlineMedium)
        Text("رقم الطوارئ (بيوصله الموقع بالرسائل)")
        OutlinedTextField(phone, { phone = it; Store.set(c, "phone", it) }, Modifier.fillMaxWidth(), singleLine = true)
        Text("كود التفعيل عن بُعد (٤ أحرف أو أكتر)")
        OutlinedTextField(pin, { pin = it; Store.set(c, "pin", it) }, Modifier.fillMaxWidth(), singleLine = true)
        Text("لو الجهاز اتسرق ابعت من أي موبايل رسالة: NIGHTGUARD ثم مسافة ثم الكود. هيتقفل ويبدأ يبعتلك الموقع.")
        Button(onClick = { a.requestPerms() }, Modifier.fillMaxWidth()) { Text("١) إعطاء الصلاحيات") }
        Button(onClick = {
            c.startActivity(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, ComponentName(c, AdminReceiver::class.java)))
        }, Modifier.fillMaxWidth()) { Text("٢) تفعيل مدير الجهاز (للقفل)") }
        Button(onClick = { Guard.trigger(c, null) }, Modifier.fillMaxWidth(), colors = Red) { Text("تفعيل وضع السرقة الآن") }
        OutlinedButton(onClick = { c.stopService(Intent(c, TheftService::class.java)) }, Modifier.fillMaxWidth()) { Text("إيقاف وضع السرقة") }
    }
}

@Composable
fun VaultScreen() {
    val c = LocalContext.current
    var notes by remember { mutableStateOf(Vault.load(c)) }
    var text by remember { mutableStateOf("") }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("الخزنة المشفّرة (AES-256)", style = MaterialTheme.typography.titleLarge)
        OutlinedTextField(text, { text = it }, Modifier.fillMaxWidth(), label = { Text("ملاحظة أو باسورد أو بيانات مهمة") })
        Button(onClick = {
            if (text.isNotBlank()) { notes = notes + text; Vault.save(c, notes); text = "" }
        }, Modifier.fillMaxWidth()) { Text("حفظ مشفّر") }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(notes.size) { i ->
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(notes[i], Modifier.weight(1f))
                        IconButton(onClick = { notes = notes.filterIndexed { j, _ -> j != i }; Vault.save(c, notes) }) {
                            Icon(Icons.Filled.Delete, "حذف")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ScanScreen() {
    val c = LocalContext.current
    val scope = rememberCoroutineScope()
    var res by remember { mutableStateOf<List<Finding>?>(null) }
    var busy by remember { mutableStateOf(false) }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("الفحص الأمني", style = MaterialTheme.typography.titleLarge)
        Button(onClick = {
            busy = true
            scope.launch { res = withContext(Dispatchers.Default) { Scanner.scan(c) }; busy = false }
        }, Modifier.fillMaxWidth(), enabled = !busy) { Text(if (busy) "جاري الفحص..." else "افحص جهازك") }
        val r = res
        if (r != null) {
            Text(if (r.isEmpty()) "لا توجد تطبيقات مشبوهة" else "${r.size} تطبيق يستحق المراجعة")
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(r) { f ->
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(f.label, style = MaterialTheme.typography.titleMedium)
                            Text(f.reasons.joinToString(" • "))
                            Button(onClick = {
                                c.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${f.pkg}")))
                            }, colors = Red) { Text("إزالة") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun NightScreen() {
    val c = LocalContext.current
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("وضع الليل", style = MaterialTheme.typography.titleLarge)
        Text("بعد التفعيل بـ ١٠ ثواني، لو الجهاز اتحرك أو اتسحب هتشتغل صفارة بأعلى صوت. أوقفها من هنا (بعد التحقق ببصمتك).")
        Button(onClick = { c.startForegroundService(Intent(c, NightService::class.java)) }, Modifier.fillMaxWidth()) { Text("تفعيل وضع الليل") }
        OutlinedButton(onClick = { c.stopService(Intent(c, NightService::class.java)) }, Modifier.fillMaxWidth()) { Text("إيقاف الحراسة والصفارة") }
    }
}
