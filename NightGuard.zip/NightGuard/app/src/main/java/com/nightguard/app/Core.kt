package com.nightguard.app

import android.app.admin.DeviceAdminReceiver
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.telephony.SmsManager
import java.io.File
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

class AdminReceiver : DeviceAdminReceiver()

object Store {
    private fun p(c: Context) = c.getSharedPreferences("ng", 0)
    fun get(c: Context, k: String): String = p(c).getString(k, "") ?: ""
    fun set(c: Context, k: String, v: String) = p(c).edit().putString(k, v).apply()
}

@Suppress("DEPRECATION")
object Guard {
    fun send(c: Context, reply: String?, loc: Location) {
        val msg = "حارس الليل: الجهاز هنا https://maps.google.com/?q=${loc.latitude},${loc.longitude}"
        listOf(Store.get(c, "phone"), reply ?: "").filter { it.isNotBlank() }.distinct().forEach {
            try {
                val sm = SmsManager.getDefault()
                sm.sendMultipartTextMessage(it, null, sm.divideMessage(msg), null, null)
            } catch (e: Exception) { }
        }
    }

    fun trigger(c: Context, reply: String?) {
        val dpm = c.getSystemService(DevicePolicyManager::class.java)
        if (dpm.isAdminActive(ComponentName(c, AdminReceiver::class.java))) dpm.lockNow()
        try {
            c.startForegroundService(Intent(c, TheftService::class.java).putExtra("reply", reply))
        } catch (e: Exception) {
            try {
                val lm = c.getSystemService(LocationManager::class.java)
                val l = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                    ?: lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
                if (l != null) send(c, reply, l)
            } catch (e2: Exception) { }
        }
    }
}

object Vault {
    private const val ALIAS = "ng_vault"
    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val g = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        g.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256).build()
        )
        return g.generateKey()
    }

    private fun file(c: Context) = File(c.filesDir, "vault.bin")

    fun save(c: Context, notes: List<String>) {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key())
        file(c).writeBytes(cipher.iv + cipher.doFinal(notes.joinToString("\u0000").toByteArray()))
    }

    fun load(c: Context): List<String> = try {
        val d = file(c).readBytes()
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, d, 0, 12))
        String(cipher.doFinal(d, 12, d.size - 12)).split("\u0000").filter { it.isNotEmpty() }
    } catch (e: Exception) { emptyList() }
}

data class Finding(val pkg: String, val label: String, val score: Int, val reasons: List<String>)

@Suppress("DEPRECATION")
object Scanner {
    fun scan(c: Context): List<Finding> {
        val pm = c.packageManager
        val flags = PackageManager.GET_PERMISSIONS or PackageManager.GET_SERVICES or PackageManager.GET_RECEIVERS
        return pm.getInstalledPackages(flags)
            .filter { (it.applicationInfo?.flags ?: 0) and ApplicationInfo.FLAG_SYSTEM == 0 && it.packageName != c.packageName }
            .map { p ->
                val perms = p.requestedPermissions?.toSet() ?: emptySet()
                var s = 0
                val r = mutableListOf<String>()
                fun add(n: Int, t: String) { s += n; r.add(t) }
                if (p.services?.any { it.permission == "android.permission.BIND_ACCESSIBILITY_SERVICE" } == true) add(3, "يستخدم خدمة إمكانية الوصول")
                if (p.receivers?.any { it.permission == "android.permission.BIND_DEVICE_ADMIN" } == true) add(2, "يطلب صلاحية مدير الجهاز")
                if ("android.permission.SYSTEM_ALERT_WINDOW" in perms) add(2, "يعرض نوافذ فوق التطبيقات")
                if ("android.permission.READ_SMS" in perms && "android.permission.SEND_SMS" in perms) add(2, "يقرأ ويرسل الرسائل")
                if ("android.permission.RECORD_AUDIO" in perms && "android.permission.CAMERA" in perms && "android.permission.ACCESS_FINE_LOCATION" in perms) add(1, "مايك وكاميرا وموقع معًا")
                if ("android.permission.REQUEST_INSTALL_PACKAGES" in perms) add(1, "يستطيع تثبيت تطبيقات")
                val src = try { pm.getInstallSourceInfo(p.packageName).installingPackageName } catch (e: Exception) { null }
                if (src != "com.android.vending") add(1, "مثبّت من خارج المتجر")
                Finding(p.packageName, p.applicationInfo?.loadLabel(pm)?.toString() ?: p.packageName, s, r)
            }
            .filter { it.score >= 3 }
            .sortedByDescending { it.score }
    }
}
