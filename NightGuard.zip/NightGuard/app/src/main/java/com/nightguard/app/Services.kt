package com.nightguard.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.LocationListener
import android.location.LocationManager
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.Build
import android.os.IBinder
import android.provider.Telephony
import kotlin.math.abs
import kotlin.math.sqrt

private fun Service.notif(id: Int, title: String, type: Int) {
    val nm = getSystemService(NotificationManager::class.java)
    nm.createNotificationChannel(NotificationChannel("ng", "Night Guard", NotificationManager.IMPORTANCE_LOW))
    val n = Notification.Builder(this, "ng").setContentTitle(title).setSmallIcon(android.R.drawable.ic_lock_lock).build()
    if (type == 0) startForeground(id, n) else startForeground(id, n, type)
}

class TheftService : Service() {
    private var last = 0L
    private var reply: String? = null
    private val listener = LocationListener { loc ->
        val now = System.currentTimeMillis()
        if (now - last > 120_000) { last = now; Guard.send(this, reply, loc) }
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        reply = i?.getStringExtra("reply") ?: reply
        notif(1, "وضع السرقة مفعّل", ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
        try {
            val lm = getSystemService(LocationManager::class.java)
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 10_000L, 0f, listener)
            lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 10_000L, 0f, listener)
        } catch (e: Exception) { }
        return START_STICKY
    }

    override fun onDestroy() {
        getSystemService(LocationManager::class.java).removeUpdates(listener)
        super.onDestroy()
    }

    override fun onBind(i: Intent?): IBinder? = null
}

class NightService : Service(), SensorEventListener {
    private var hits = 0
    private var armedAt = 0L
    private var ring: Ringtone? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        notif(2, "وضع الليل يحرس الجهاز", if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0)
        armedAt = System.currentTimeMillis() + 10_000
        val sm = getSystemService(SensorManager::class.java)
        sm.registerListener(this, sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_NORMAL)
        return START_STICKY
    }

    override fun onSensorChanged(e: SensorEvent) {
        if (System.currentTimeMillis() < armedAt) return
        val g = sqrt(e.values[0] * e.values[0] + e.values[1] * e.values[1] + e.values[2] * e.values[2])
        if (abs(g - 9.81f) > 3f) { hits++; if (hits >= 3) alarm() } else hits = maxOf(0, hits - 1)
    }

    private fun alarm() {
        if (ring?.isPlaying == true) return
        val am = getSystemService(AudioManager::class.java)
        am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0)
        ring = RingtoneManager.getRingtone(this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)).apply {
            audioAttributes = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build()
            isLooping = true
            play()
        }
    }

    override fun onAccuracyChanged(s: Sensor?, a: Int) {}

    override fun onDestroy() {
        getSystemService(SensorManager::class.java).unregisterListener(this)
        ring?.stop()
        super.onDestroy()
    }

    override fun onBind(i: Intent?): IBinder? = null
}

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(i)
        val body = msgs.joinToString("") { it.messageBody ?: "" }.trim()
        val pin = Store.get(c, "pin")
        if (pin.length >= 4 && body == "NIGHTGUARD $pin") Guard.trigger(c, msgs.firstOrNull()?.originatingAddress)
    }
}
